// devtools.js
chrome.devtools.panels.create(
  'Analyze DOM size',
  '',
  'index.html',
  () => {}
);